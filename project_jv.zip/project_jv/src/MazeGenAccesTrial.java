import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.ArrayList;
import java.util.Random;

public class MazeGenAccesTrial extends JPanel {

	static final int WALL = 0, PATH = 1, EXIT = 4;
	static final int POWER_SPEED = 5, POWER_FREEZE = 6, POWER_SHIELD = 7;

	private static int rows, cols;
	private static int[][] maze;

	private static int herosX, herosY;
	private static boolean jeuEnCours = true;

	private static final int CELL_SIZE = 15;
	private static JFrame frame;
	private static MazeGenAccesTrial panel;

	private static JLabel timerLabel;
	private static int secondesEcoulees = 0;
	private static Timer timer;

	private static ArrayList<Projectile> projectiles = new ArrayList<>();
	private static int ammo = 5; // starting ammo
	private static int shotDirX = 0, shotDirY = -1; // initial shooting direction (up)
	private static final int POWER_AMMO = 8; // optional power-up for ammo

	static boolean speedBoost = false;
	static boolean freezeEnemies = false;
	static boolean shield = false;
	private static Timer powerTimer;
	private static Timer enemySpawnTimer;

	private static int lastHeroDX = 0;
	private static int lastHeroDY = 0;

	private static ArrayList<Enemy> enemies = new ArrayList<>();
	private static Random rand = new Random();

	private static String[][] mapsChoisies;
	private static Timer projectileTimer;

	private JButton retryButton;

	public static void main(String[] args) {
		SwingUtilities.invokeLater(MazeGenAccesTrial::afficherDifficulte);
	}

	private static void afficherDifficulte() {
		JFrame difficulteFrame = new JFrame("Choisissez la difficulté");
		difficulteFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		difficulteFrame.setSize(300, 200);
		difficulteFrame.setLocationRelativeTo(null);
		difficulteFrame.setLayout(new GridLayout(4, 1, 10, 10));

		JLabel lbl = new JLabel("Sélectionnez la difficulté :", SwingConstants.CENTER);
		JButton facileBtn = new JButton("Facile");
		JButton moyenBtn = new JButton("Moyen");
		JButton difficileBtn = new JButton("Difficile");

		facileBtn.addActionListener(e -> {
			mapsChoisies = maps_facile.maps_facile;
			rows = 32;
			cols = 32;
			difficulteFrame.dispose();
			afficherMenu();
		});
		moyenBtn.addActionListener(e -> {
			mapsChoisies = maps_moyen.maps_moyen;
			rows = 64;
			cols = 64;
			difficulteFrame.dispose();
			afficherMenu();
		});
		difficileBtn.addActionListener(e -> {
			mapsChoisies = maps_difficile.maps_difficile;
			rows = 128;
			cols = 128;
			difficulteFrame.dispose();
			afficherMenu();
		});

		difficulteFrame.add(lbl);
		difficulteFrame.add(facileBtn);
		difficulteFrame.add(moyenBtn);
		difficulteFrame.add(difficileBtn);
		difficulteFrame.setVisible(true);
	}

	private static void afficherMenu() {
		JFrame menuFrame = new JFrame("🎮 Menu du jeu - MazeGen");
		menuFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		menuFrame.setSize(300, 250);
		menuFrame.setLocationRelativeTo(null);
		menuFrame.setLayout(new GridLayout(6, 1, 10, 10));

		JLabel lblNiveau = new JLabel("Choisissez un niveau :", SwingConstants.CENTER);
		JComboBox<Integer> niveauBox = new JComboBox<>();
		for (int i = 1; i <= mapsChoisies.length; i++)
			niveauBox.addItem(i);

		JButton jouerBtn = new JButton("🚀 Jouer !");
		jouerBtn.addActionListener(e -> {
			int niveauChoisi = (int) niveauBox.getSelectedItem();
			maze = new int[rows][cols];
			enemies.clear();
			String[] mapSelectionnee = mapsChoisies[niveauChoisi - 1];
			for (int i = 0; i < rows; i++)
				for (int j = 0; j < cols; j++)
					maze[i][j] = mapSelectionnee[i].charAt(j) == '0' ? WALL : PATH;

			herosX = 1;
			herosY = 1;
			placeRandomExit();

			menuFrame.dispose();
			createAndShowGUI();
		});

		menuFrame.add(new JLabel(""));
		menuFrame.add(lblNiveau);
		menuFrame.add(niveauBox);
		menuFrame.add(new JLabel(""));
		menuFrame.add(jouerBtn);
		menuFrame.add(new JLabel(""));
		menuFrame.setVisible(true);
	}

	private static void createAndShowGUI() {
		jeuEnCours = true;
		projectileTimer = new Timer(60, new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				updateProjectiles();
				panel.repaint();
			}
		});
		projectileTimer.start();

		Timer powerSpawn = new Timer(12000, ev -> spawnPowerUp());
		powerSpawn.start();

		frame = new JFrame("Maze Game 🧩");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		panel = new MazeGenAccesTrial();
		panel.setPreferredSize(new Dimension(cols * CELL_SIZE, rows * CELL_SIZE + 50));
		panel.setFocusable(true);
		panel.setupRetryButton();

		timerLabel = new JLabel("Temps: 0s", SwingConstants.CENTER);
		timerLabel.setFont(new Font("Arial", Font.BOLD, 16));
		frame.add(timerLabel, BorderLayout.NORTH);

		secondesEcoulees = 0;
		timer = new Timer(1000, ev -> {
			secondesEcoulees++;
			timerLabel.setText("Temps: " + secondesEcoulees + "s");
		});
		timer.start();

		// ---- Projectiles move independently ----
		projectileTimer = new Timer(60, new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				updateProjectiles();
				panel.repaint();
			}
		});
		projectileTimer.start();

		panel.addKeyListener(new KeyAdapter() {
		@Override
			public void keyPressed(KeyEvent e) {
				if (!jeuEnCours)
					return;

				// Direction keys for shooting
				switch (e.getKeyCode()) {
				case KeyEvent.VK_Z -> {
					shotDirX = 0;
					shotDirY = -1;
				}
				case KeyEvent.VK_S -> {
					shotDirX = 0;
					shotDirY = 1;
				}
				case KeyEvent.VK_Q -> {
					shotDirX = -1;
					shotDirY = 0;
				}
				case KeyEvent.VK_D -> {
					shotDirX = 1;
					shotDirY = 0;
				}
				case KeyEvent.VK_SPACE -> {
					if (ammo > 0) {
						projectiles.add(new Projectile(herosX, herosY, shotDirX, shotDirY));
						ammo--;
					}
				}
				}

				// Hero movement
				int[] pos = mouvement(herosX, herosY, e.getKeyCode(), maze);
				herosX = pos[0];
				herosY = pos[1];

				// Track last hero movement (for knockback)
				switch (e.getKeyCode()) {
				case KeyEvent.VK_UP -> {
					lastHeroDX = 0;
					lastHeroDY = -1;
				}
				case KeyEvent.VK_DOWN -> {
					lastHeroDX = 0;
					lastHeroDY = 1;
				}
				case KeyEvent.VK_LEFT -> {
					lastHeroDX = -1;
					lastHeroDY = 0;
				}
				case KeyEvent.VK_RIGHT -> {
					lastHeroDX = 1;
					lastHeroDY = 0;
				}
				}

				// Enemy movement
				for (Enemy en : enemies)
					if (!freezeEnemies)
						en.moveToward(herosX, herosY, maze);

				// Hero death / shield
				if (verifierMort(herosX, herosY)) {
					if (shield) {
						shield = false;
						pushEnemyBack(herosX, herosY);
					} else
						gameOverWithPopup();
				}

				// Power-ups pickup
				int tile = maze[herosY][herosX];
				if (tile == POWER_SPEED) {
					activateSpeedBoost();
					maze[herosY][herosX] = PATH;
				} else if (tile == POWER_FREEZE) {
					activateFreeze();
					maze[herosY][herosX] = PATH;
				} else if (tile == POWER_SHIELD) {
					activateShield();
					maze[herosY][herosX] = PATH;
				} else if (tile == POWER_AMMO) {
					ammo += 3;
					maze[herosY][herosX] = PATH;
				}

				if (tile == EXIT)
					gameOverWithPopup(true);

				panel.repaint();
			}

		});

		frame.add(panel, BorderLayout.CENTER);
		frame.pack();
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);
		panel.requestFocusInWindow();
	}

	// ---------------- Power-ups ----------------
	private static void activateSpeedBoost() {
		speedBoost = true;
		if (powerTimer != null)
			powerTimer.stop();
		powerTimer = new Timer(6000, e -> speedBoost = false);
		powerTimer.setRepeats(false);
		powerTimer.start();
	}

	private static void activateFreeze() {
		freezeEnemies = true;
		if (powerTimer != null)
			powerTimer.stop();
		powerTimer = new Timer(5000, e -> freezeEnemies = false);
		powerTimer.setRepeats(false);
		powerTimer.start();
	}

	private static void activateShield() {
		shield = true;
		if (powerTimer != null)
			powerTimer.stop();
		powerTimer = new Timer(10000, e -> shield = false);
		powerTimer.setRepeats(false);
		powerTimer.start();
	}

	private static void spawnPowerUp() {
		int x, y, tries = 0;
		int[] types = { POWER_SPEED, POWER_FREEZE, POWER_SHIELD };
		do {
			x = rand.nextInt(cols);
			y = rand.nextInt(rows);
			tries++;
		} while (tries < 200 && maze[y][x] != PATH);
		if (tries < 200)
			maze[y][x] = types[rand.nextInt(types.length)];
	}

	// ---------------- Exit ----------------
	private static void placeRandomExit() {
		ArrayList<int[]> possibleExits = new ArrayList<>();
		for (int x = 1; x < cols - 1; x++) {
			if (maze[1][x] == PATH)
				possibleExits.add(new int[] { x, 0 });
			if (maze[rows - 2][x] == PATH)
				possibleExits.add(new int[] { x, rows - 1 });
		}
		for (int y = 1; y < rows - 1; y++) {
			if (maze[y][1] == PATH)
				possibleExits.add(new int[] { 0, y });
			if (maze[y][cols - 2] == PATH)
				possibleExits.add(new int[] { cols - 1, y });
		}
		if (!possibleExits.isEmpty()) {
			int[] exitPos = possibleExits.get(rand.nextInt(possibleExits.size()));
			maze[exitPos[1]][exitPos[0]] = EXIT;
		}
	}

	// ---------------- Enemy ----------------
	private static void spawnEnemy() {
		int x, y, tries = 0;
		do {
			x = rand.nextInt(cols);
			y = rand.nextInt(rows);
			tries++;
		} while (tries < 200 && (maze[y][x] != PATH || (Math.abs(x - herosX) < 3 && Math.abs(y - herosY) < 3)));
		if (tries < 200)
			enemies.add(new Enemy(x, y));
	}

	private static boolean verifierMort(int hx, int hy) {
		for (Enemy e : enemies)
			if (e.x == hx && e.y == hy)
				return true;
		return false;
	}

	private static void pushEnemyBack(int hx, int hy) {
		for (Enemy e : enemies) {
			if (e.x == hx && e.y == hy) {
				// Use opposite direction of hero's last movement
				int dx = -lastHeroDX;
				int dy = -lastHeroDY;

				// fallback if hero didn't move (unlikely)
				if (dx == 0 && dy == 0)
					dy = 1;

				int push = 3;
				int newX = e.x;
				int newY = e.y;

				for (int i = 0; i < push; i++) {
					int nextX = newX + dx;
					int nextY = newY + dy;

					if (nextX < 0 || nextX >= cols || nextY < 0 || nextY >= rows)
						break;
					if (maze[nextY][nextX] == WALL)
						break;

					newX = nextX;
					newY = nextY;
				}

				animateKnockback(e, newX, newY);
			}
		}
	}

	private static void animateKnockback(Enemy e, int targetX, int targetY) {
		e.isKnockback = true;
		e.kbFrames = 8;
		double dx = (targetX - e.animX) / e.kbFrames, dy = (targetY - e.animY) / e.kbFrames;
		Timer anim = new Timer(20, null);
		anim.addActionListener(ev -> {
			if (e.kbFrames <= 0) {
				e.isKnockback = false;
				e.x = (int) (e.animX = targetX);
				e.y = (int) (e.animY = targetY);
				anim.stop();
				panel.repaint();
				return;
			}
			e.animX += dx;
			e.animY += dy;
			e.kbFrames--;
			panel.repaint();
		});
		anim.start();
	}

	public static int[] mouvement(int hx, int hy, int keyCode, int[][] carte) {
		int step = speedBoost ? 2 : 1;
		int newX = hx, newY = hy;
		switch (keyCode) {
		case KeyEvent.VK_UP -> newY = hy - step;
		case KeyEvent.VK_DOWN -> newY = hy + step;
		case KeyEvent.VK_LEFT -> newX = hx - step;
		case KeyEvent.VK_RIGHT -> newX = hx + step;
		default -> {
			return new int[] { hx, hy };
		}
		}
		if (newY < 0 || newY >= carte.length || newX < 0 || newX >= carte[0].length)
			return new int[] { hx, hy };
		if (carte[newY][newX] == WALL)
			return new int[] { hx, hy };
		return new int[] { newX, newY };
	}

	// ---------------- Retry/GameOver ----------------
	private void setupRetryButton() {
		retryButton = new JButton("Retry");
		retryButton.setVisible(false);
		retryButton.addActionListener(e -> showRetryPopup());
		this.add(retryButton);
	}

	private static void showRetryPopup() {
		int result = JOptionPane.showConfirmDialog(frame, "Voulez-vous rejouer?", "Retry", JOptionPane.YES_NO_OPTION);
		if (result == JOptionPane.YES_OPTION)
			fadeOutAndRestart();
		else
			frame.dispose();
	}

	private static void fadeOutAndRestart() {
		new Thread(() -> {
			for (int i = 255; i >= 0; i -= 5) {
				final int alpha = i;
				SwingUtilities.invokeLater(() -> panel.setBackground(new Color(255, 255, 255, alpha)));
				try {
					Thread.sleep(10);
				} catch (Exception ex) {
				}
			}
			SwingUtilities.invokeLater(() -> {
				if (timer != null)
					timer.stop();
				if (enemySpawnTimer != null)
					enemySpawnTimer.stop();
				panel = null;
				enemies.clear();
				frame.dispose();
				frame = null;
				jeuEnCours = true;
				secondesEcoulees = 0;
				MazeGenAccesTrial.main(new String[] {});
			});
		}).start();
	}

	private static void gameOverWithPopup() {
		gameOverWithPopup(false);
	}

	private static void gameOverWithPopup(boolean victory) {
		jeuEnCours = false;
		timer.stop();
		enemySpawnTimer.stop();
		if (victory)
			JOptionPane.showMessageDialog(frame, "🎉 VICTOIRE 🎉", "Bravo!", JOptionPane.INFORMATION_MESSAGE);
		else
			JOptionPane.showMessageDialog(frame, "💀 GAME OVER 💀", "Défaite", JOptionPane.ERROR_MESSAGE);
		showRetryPopup();
	}

	// ---------------- Paint ----------------
	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		for (int i = 0; i < rows; i++) {
			for (int j = 0; j < cols; j++) {
				int x = j * CELL_SIZE, y = i * CELL_SIZE;
				switch (maze[i][j]) {
				case WALL -> g.setColor(Color.BLACK);
				case EXIT -> g.setColor(Color.GREEN);
				case POWER_SPEED -> g.setColor(Color.CYAN);
				case POWER_FREEZE -> g.setColor(Color.MAGENTA);
				case POWER_SHIELD -> g.setColor(Color.ORANGE);
				default -> g.setColor(Color.WHITE);
				}
				g.fillRect(x, y, CELL_SIZE, CELL_SIZE);
			}
		}
		g.setColor(Color.MAGENTA);
		for (Projectile p : projectiles) {
			g.fillOval(p.x * CELL_SIZE + 5, p.y * CELL_SIZE + 5, CELL_SIZE - 10, CELL_SIZE - 10);
		}

		g.setColor(Color.BLUE);
		g.fillOval(herosX * CELL_SIZE + 2, herosY * CELL_SIZE + 2, CELL_SIZE - 4, CELL_SIZE - 4);
		g.setColor(Color.RED);
		for (Enemy e : enemies) {
			double drawX = e.isKnockback ? e.animX : e.x;
			double drawY = e.isKnockback ? e.animY : e.y;
			g.fillOval((int) (drawX * CELL_SIZE + 2), (int) (drawY * CELL_SIZE + 2), CELL_SIZE - 4, CELL_SIZE - 4);
		}
	}

	// ---------------- Projectiles ----------------

	private static void updateProjectiles() {
		ArrayList<Projectile> toRemove = new ArrayList<>();
		for (Projectile p : projectiles) {
			p.move(maze);

			// check collision with enemies
			for (Enemy en : enemies) {
				if (p.x == en.x && p.y == en.y) {
					enemies.remove(en);
					p.active = false;
					break;
				}
			}

			if (!p.active)
				toRemove.add(p);
		}
		projectiles.removeAll(toRemove);
	}
}
